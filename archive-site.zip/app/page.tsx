import Link from "next/link";

export default function Home() {
  return (
    <main>
      <h1 className="h1">개인 아카이브</h1>
      <p className="small">
        CD/LP · 책 · 영화 기록을 한 곳에. (현재 MVP는 Music부터)
      </p>

      <div style={{ marginTop: 16 }}>
        <Link className="pill" href="/music">Music로 가기 →</Link>
      </div>
    </main>
  );
}
