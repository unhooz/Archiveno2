import { getAlbum } from "@/lib/albums";
import Link from "next/link";
import { notFound } from "next/navigation";
import AlbumDetailClient from "@/components/AlbumDetailClient";

export default function AlbumDetail({ params }: { params: { slug: string } }) {
  const album = getAlbum(params.slug);
  if (!album) return notFound();

  return (
    <main>
      <div className="toprow">
        <div>
          <h1 className="h1" style={{ marginBottom: 4 }}>{album.title}</h1>
          <div className="small">{album.artist} · {album.format} · {album.release_year}</div>
        </div>
        <Link className="pill" href="/music">← Music</Link>
      </div>

      <AlbumDetailClient album={album} />
    </main>
  );
}
